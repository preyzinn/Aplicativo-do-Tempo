import requests
import tkinter as tk
from tkinter import Label

def clima(cidade):
    api_key = "4c60d81d6fed58d57ba080a02e83681f"
    url = f'http://api.openweathermap.org/data/2.5/weather?q={cidade}&appid={api_key}'

    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        temp = data['main']['temp']
        desc = data['weather'][0]['description']
        c = temp - 273
        c = int(c)
        print(f'Temperatura: {c} graus')
        print(f'situacao: {desc}')
        return c, desc
    else:
        print('Erro ao coisas as informaçoes')
        return "Erro"


def mostrar():
    cidade = entrada.get()
    temp_desc = clima(cidade)

    if temp_desc == "Erro":
        sexo.config(text="Deu erro irmao", font=("Arial", 20))
    else:
        sexo.config(text=f"{temp_desc[0]}° Celsius \n Descrição: {temp_desc[1]}", font=("Arial", 15))

root = tk.Tk()
root.title("caralho")

fodase = Label(root, text="clima", font=("Arial", 20))
fodase.pack(pady=10)

entrada = tk.Entry(root)
entrada.pack(pady=10)


botao = tk.Button(root, text="ATIVAR CLIMA", command=mostrar)
botao.pack(pady=10)

sexo = Label(root, text="")
sexo.pack()

root.mainloop()










